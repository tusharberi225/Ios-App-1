//
//  ViewController.swift
//  RainbowColor
//
//  Created by TUSHAR BERI on 26/06/18.
//  Copyright © 2018 tired guardian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Brown(_ sender: Any) {
        self.view.backgroundColor = UIColor.brown
    }
    @IBAction func Red(_ sender: Any) {
        self.view.backgroundColor = UIColor.red
    }
    
    @IBAction func Blue(_ sender: Any) {
          self.view.backgroundColor = UIColor.blue
        
    }
    @IBAction func Green(_ sender: Any) {
          self.view.backgroundColor = UIColor.green
    }
    @IBAction func Yellow(_ sender: Any) {
          self.view.backgroundColor = UIColor.yellow
    }
    @IBAction func Black(_ sender: Any) {
          self.view.backgroundColor = UIColor.black
    }
    @IBAction func White(_ sender: Any) {
          self.view.backgroundColor = UIColor.white
    }
    
}

